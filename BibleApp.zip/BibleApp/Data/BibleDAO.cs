﻿using BibleApp.Models;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BibleApp.Data
{
    internal class BibleDAO
    {
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bible;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        // Perform all the operations on the database. Get all, create, delete, get one, search etc...

        public List<BibleVerseModel> FetchAll()
        {
            List<BibleVerseModel> returnList = new List<BibleVerseModel>();

            // Access the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * from dbo.t_asv";

                SqlCommand command = new SqlCommand(sqlQuery, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader(); // Read the select statement

                if(reader.HasRows)
                {
                    while(reader.Read())
                    {
                        // Create a new bible verse object. Add it to the list to return.
                        BibleVerseModel bibleVerse = new BibleVerseModel();
                        bibleVerse.Id = reader.GetInt32(0); // In column 1
                        bibleVerse.BookSelection = reader.GetInt32(1); // In column 2
                        bibleVerse.ChapterNumber = reader.GetInt32(2);
                        bibleVerse.VerseNumber = reader.GetInt32(3);
                        bibleVerse.Text = reader.GetString(4);


                        returnList.Add(bibleVerse);
                    }
                }

            }
            return returnList;
        }
    }
}