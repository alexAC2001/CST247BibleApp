﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace BibleApp.Models
{
    // This class will be the basis of what a verse is.
    public class BibleVerseModel
    {
        [DisplayName("Id number")]
        public int Id { get; set; }
        [DisplayName("Book")]
        public int BookSelection { get; set; }
        [DisplayName("Chapter #")]
        public int ChapterNumber { get; set;} 
        [DisplayName("Verse #")]
        public int VerseNumber { get; set; }
        [DisplayName("Text")]
        public string Text { get; set; }

        public string toString()
        {
            return "Id: " + Id + " BookSelection: " + BookSelection + " ChapterNumber: " + ChapterNumber + " VerseNumber; " + VerseNumber + " Text: " + Text;
        }

    }
}
