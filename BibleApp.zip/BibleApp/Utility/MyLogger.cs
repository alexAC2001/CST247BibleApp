﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BibleApp.Utility
{
    // This class implements the methods from the ILogger interface so application can effectively log data.
    public class MyLogger : ILogger
    {
        // Single design pattern used here

        private static MyLogger instance;
        private static Logger logger;

        public static MyLogger GetInstance()
        {
            if (instance == null)
            {
                instance = new MyLogger();
            }
            return instance; // Only return one instance
        }

        public Logger GetLogger()
        {
            if(MyLogger.logger == null)            
                MyLogger.logger = LogManager.GetLogger("BibleRule"); // Rule from the NLog.config file
            return MyLogger.logger;
        }

        public void Debug(string message)
        {
            GetLogger().Debug(message);
        }

        public void Error(string message)
        {
            GetLogger().Error(message);
        }

        public void Info(string message)
        {
            GetLogger().Info(message);
        }

        public void Warning(string message)
        {
            GetLogger().Warn(message);
        }
    }
}
