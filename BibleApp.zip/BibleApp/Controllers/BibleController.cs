﻿using BibleApp.Data;
using BibleApp.Models;
using BibleApp.Services;
using BibleApp.Utility;
using Bogus;
using Microsoft.AspNetCore.Mvc;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BibleApp.Controllers
{
    // This is the BibleController class which contains method to allow the user to perform various actions.
    public class BibleController : Controller
    {
        // Here is the dependency injection where the BibleVerseDAO is used as a type IBibleDataService. 
        // It is referenced as repository.
        public IBibleDataService repository { get; set; }
        public BibleController(IBibleDataService dataService)
        {
            repository = dataService;
        }

        // This method returns all the bible verses from the database
        public IActionResult Index()
        {
            // Log info
            MyLogger.GetInstance().Info("Entered the Index method to show all verses...");
            //List<BibleVerseModel> bibleVerses = new List<BibleVerseModel>();
            //BibleVerseDAO bibleDAO = new BibleVerseDAO();
            //bibleVerses = bibleDAO.GetAllVerses();
            return View(repository.GetAllVerses());
        }

        // This method shows the details for one bible verse
        public ActionResult Details(int id)
        {
            MyLogger.GetInstance().Info("Entered the Details method...");
            MyLogger.GetInstance().Info("Verse ID: " + id);
            //BibleVerseDAO verseDAO = new BibleVerseDAO();
            //BibleVerseModel verse = verseDAO.GetOneVerse(id);
            return View("Details", repository.GetOneVerse(id));
        }

        // This method is for displaying the Edit form
        public ActionResult Edit(int id)
        {
            MyLogger.GetInstance().Info("Entered the Edit method...");
            //BibleVerseDAO verseDAO = new BibleVerseDAO();
            //BibleVerseModel verse = verseDAO.GetOneVerse(id);
            return View("ShowEdit", repository.GetOneVerse(id));
        }

        // This method is for saving the changes made to a verse to the database
        public ActionResult ProcessEdit(BibleVerseModel verse)
        {
            MyLogger.GetInstance().Info("Entered the ProcessEdit method...");
            MyLogger.GetInstance().Info("Processing Changes");
            //BibleVerseDAO verseDAO = new BibleVerseDAO();
            repository.Update(verse);
            return View("Index", repository.GetAllVerses());
        }

        // This simply shows the SearchForm view
        public ActionResult SearchForm()
        {
            MyLogger.GetInstance().Info("Entered the SearchForm method...");
            return View("SearchForm");
        }

        // This method generates a list of bible verses that correspond with the user's search phrase
        public IActionResult SearchResults(string searchPhrase)
        {
            MyLogger.GetInstance().Info("Processing a search attempt...");
            MyLogger.GetInstance().Info("Search Phrase: " + searchPhrase);
            ///BibleVerseDAO verses = new BibleVerseDAO();
            List<BibleVerseModel> bibleVerseList = repository.SearchVerses(searchPhrase);
            return View("Index", bibleVerseList);
        }

        // This method simply shows the form to create/insert a new bible verse
        public ActionResult Create()
        {
            MyLogger.GetInstance().Info("Entered the Create method...");
            return View("CreateVerseForm");
        }

        // This method is for saving the new verse to the database
        public ActionResult ProcessCreate(BibleVerseModel verse)
        {
            MyLogger.GetInstance().Info("Executing the ProcessCreate method...");
            MyLogger.GetInstance().Info("Created Verse: " + verse.toString());
            // Save it to the database
            //BibleVerseDAO verseDAO = new BibleVerseDAO();
            repository.Create(verse);
            return View("Details", verse);
        }
    }
}
