﻿using BibleApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BibleApp.Services
{
    // This is the IBibleDataService so the DAO class can implement these methods.
    public interface IBibleDataService
    {
        List<BibleVerseModel> GetAllVerses();
        BibleVerseModel GetOneVerse(int id);
        List<BibleVerseModel> SearchVerses(string searchTerm);
        BibleVerseModel GetVerseById(int id);

        int Create(BibleVerseModel verse);
        int Delete(BibleVerseModel verse);
        int Update(BibleVerseModel verse);
    }
}
