﻿using BibleApp.Models;
using BibleApp.Services;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BibleApp.Services
{
    // This class is the DAO class that contains the database methods for Bible verses
    internal class BibleVerseDAO : IBibleDataService  
    {
        private string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bible;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public int Delete(BibleVerseModel verse)
        {
            throw new System.NotImplementedException();
        }

        // Perform all the operations on the database. Get all, create, delete, get one, search etc...

        public List<BibleVerseModel> GetAllVerses()
        {
            List<BibleVerseModel> returnList = new List<BibleVerseModel>();

            // Access the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * from dbo.t_asv";

                SqlCommand command = new SqlCommand(sqlQuery, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader(); // Read the select statement

                if(reader.HasRows)
                {
                    while(reader.Read())
                    {
                        // Create a new bible verse object. Add it to the list to return.
                        BibleVerseModel bibleVerse = new BibleVerseModel();
                        bibleVerse.Id = reader.GetInt32(0); // In column 1
                        bibleVerse.BookSelection = reader.GetInt32(1); // In column 2
                        bibleVerse.ChapterNumber = reader.GetInt32(2);
                        bibleVerse.VerseNumber = reader.GetInt32(3);
                        bibleVerse.Text = reader.GetString(4);


                        returnList.Add(bibleVerse);
                    }
                }

            }
            return returnList;
        }

        public BibleVerseModel GetOneVerse(int id)
        {           
            // Access the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * from dbo.t_asv WHERE id = @id";

                SqlCommand command = new SqlCommand(sqlQuery, connection);
                
                // associate @id with id parameter
                command.Parameters.Add("@Id", System.Data.SqlDbType.Int).Value = id;

                connection.Open();
                SqlDataReader reader = command.ExecuteReader(); // Read the select statement

                BibleVerseModel bibleVerse = new BibleVerseModel();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        bibleVerse.Id = reader.GetInt32(0); // In column 1
                        bibleVerse.BookSelection = reader.GetInt32(1); // In column 2
                        bibleVerse.ChapterNumber = reader.GetInt32(2);
                        bibleVerse.VerseNumber = reader.GetInt32(3);
                        bibleVerse.Text = reader.GetString(4);

                                                
                    }
                }
                 return bibleVerse;
            }
           
        }

        public BibleVerseModel GetVerseById(int id)
        {
            throw new System.NotImplementedException();
        }        

        public int Create(BibleVerseModel verse)
        {
            List<BibleVerseModel> returnList = new List<BibleVerseModel>();

            // Access the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlQuery = "INSERT INTO dbo.t_asv VALUES(@BookSelection, @ChapterNumber, @VerseNumber, @Text)";

                SqlCommand command = new SqlCommand(sqlQuery, connection);

                command.Parameters.Add("@BookSelection", System.Data.SqlDbType.VarChar, 1000).Value = verse.BookSelection;
                command.Parameters.Add("@ChapterNumber", System.Data.SqlDbType.VarChar, 1000).Value = verse.ChapterNumber;
                command.Parameters.Add("@VerseNumber", System.Data.SqlDbType.VarChar, 1000).Value = verse.VerseNumber;
                command.Parameters.Add("@Text", System.Data.SqlDbType.VarChar, 1000).Value = verse.Text;

                connection.Open();

                int newID = command.ExecuteNonQuery();
                return newID;
            }            
        }

        public List<BibleVerseModel> SearchVerses(string searchPhrase)
        {
            List<BibleVerseModel> returnList = new List<BibleVerseModel>();

            // Access the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * from dbo.t_asv WHERE t LIKE @searchForMe";

                SqlCommand command = new SqlCommand(sqlQuery, connection);

                command.Parameters.Add("@searchForMe", System.Data.SqlDbType.NVarChar).Value = "%" + searchPhrase + "%";

                connection.Open();
                SqlDataReader reader = command.ExecuteReader(); // Read the select statement
                //command.Parameters.AddWithValue("@Text", '%' + searchTerm + '%'); // Match all verses with the search term

                string error;

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // Get the bible verse object. Add it to the list to return.
                        BibleVerseModel bibleVerse = new BibleVerseModel();
                        bibleVerse.Id = reader.GetInt32(0); // In column 1
                        bibleVerse.BookSelection = reader.GetInt32(1); // In column 2
                        bibleVerse.ChapterNumber = reader.GetInt32(2);
                        bibleVerse.VerseNumber = reader.GetInt32(3);
                        bibleVerse.Text = reader.GetString(4);


                        returnList.Add(bibleVerse);
                    }
                }
                else
                {
                    error = "Record does not exits";
                }
            }
            return returnList;
        }

        public int Update(BibleVerseModel verse)
        {
            int newIdNumber = -1;
            string sqlQuery = "UPDATE * from dbo.t_asv SET b = @BookSelection, c = @ChapterNumber, v = @VerseNumber, t @Text WHERE id = @id";

            // Access the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlQuery, connection);
                command.Parameters.AddWithValue("@BookSelection", verse.BookSelection);
                command.Parameters.AddWithValue("@ChapterNumber", verse.ChapterNumber);
                command.Parameters.AddWithValue("@VerseNumber", verse.VerseNumber);
                command.Parameters.AddWithValue("@Text", verse.Text);

                try
                {
                    connection.Open();
                    newIdNumber = Convert.ToInt32(command.ExecuteScalar());

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return newIdNumber;
        }
    }
}